﻿using Microsoft.Maui.Controls;

namespace TermTracker
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
