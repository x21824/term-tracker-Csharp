﻿using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using TermTracker.Models;

namespace TermTracker.Database
{
    public class SqliteDataService : ILocalDataService
    {
        private SQLiteConnection database;

        public bool Initialize()
        {
            if (database == null)
            {
                string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TermTrackerDb.db3");
                database = new SQLiteConnection(dbPath);
            }

            bool termTableCreated = database.CreateTable<Term>() == CreateTableResult.Created;
            bool courseTableCreated = database.CreateTable<Course>() == CreateTableResult.Created;
            bool assessmentTableCreated = database.CreateTable<Assessment>() == CreateTableResult.Created;

            return termTableCreated || courseTableCreated || assessmentTableCreated;
        }

        public void AddTerm(Term term) => database.Insert(term);
        public List<Term> GetAllTerms() => database.Table<Term>().ToList();
        public List<Course> GetAllCourses() => database.Table<Course>().ToList();
        public List<Assessment> GetAllAssessments() => database.Table<Assessment>().ToList();
        public int UpdateTerm(Term term) => database.Update(term);
        public int DeleteTerm(Term term) => database.Delete(term);
        public void AddCourse(Course course) => database.Insert(course);
        public List<Course> GetCoursesByTermId(int termId) => database.Query<Course>($"SELECT * FROM Course WHERE TermId={termId}");
        public int UpdateCourse(Course course) => database.Update(course);
        public int DeleteCourse(Course course) => database.Delete(course);
        public void AddAssessment(Assessment assessment) => database.Insert(assessment);
        public List<Assessment> GetAssessmentsByCourseId(int courseId) => database.Query<Assessment>($"SELECT * FROM Assessment WHERE CourseId={courseId}");
        public int UpdateAssessment(Assessment assessment) => database.Update(assessment);
        public int DeleteAssessment(Assessment assessment) => database.Delete(assessment);
        public void Close() => database.Close();
    }
}
