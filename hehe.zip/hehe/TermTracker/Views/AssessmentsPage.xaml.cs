﻿using Microsoft.Maui.Controls;
using TermTracker.Models;

namespace TermTracker.Views
{
    public partial class AssessmentsPage : ContentPage
    {
        private readonly int _courseId;

        public AssessmentsPage(int courseId)
        {
            InitializeComponent();
            _courseId = courseId;
            Globals.InitializeAssessmentCollection(_courseId);
            AssessmentsListView.ItemsSource = Globals.Assessments;
        }

        private async void AddAssessment_Clicked(object sender, EventArgs e)
        {
            // Check if the maximum number of assessments (2) has been reached
            Globals.InitializeAssessmentCollection(_courseId); // Initialize to ensure the count is up-to-date

            if (Globals.Assessments.Count >= 2)
            {
                await DisplayAlert("Error", "You cannot add more than 2 assessments to a course.", "OK");
                return;
            }

            // Check for existing assessment types to enforce 1 objective and 1 performance assessment
            if (Globals.Assessments.Count(a => a.Type == "Objective") >= 1 && Globals.Assessments.Count(a => a.Type == "Performance") >= 1)
            {
                await DisplayAlert("Error", "You can only have one Objective and one Performance assessment per course.", "OK");
                return;
            }

            await Navigation.PushModalAsync(new AssessmentConstructPage(_courseId));
        }


        private async void OnAssessmentSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem != null)
            {
                var selectedAssessment = (Assessment)e.SelectedItem;
                await Navigation.PushModalAsync(new AssessmentConstructPage(selectedAssessment));
                AssessmentsListView.SelectedItem = null;
            }
        }
    }
}
