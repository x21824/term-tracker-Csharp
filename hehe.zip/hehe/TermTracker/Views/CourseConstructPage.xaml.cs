﻿using System;
using System.Text.RegularExpressions;
using TermTracker.Models;
using Microsoft.Maui.Controls;

namespace TermTracker.Views
{
    public partial class CourseConstructPage : ContentPage
    {
        private readonly int _termId;
        private readonly Course _courseToEdit;

        public CourseConstructPage(int termId)
        {
            InitializeComponent();
            _termId = termId;
            _courseToEdit = null;
        }

        public CourseConstructPage(Course course)
        {
            InitializeComponent();
            _courseToEdit = course;
            SetData(course);
        }

        private void SetData(Course course)
        {
            TitleEntry.Text = course.Title;
            StartDatePicker.Date = course.StartDate;
            EndDatePicker.Date = course.EndDate;
            StatusPicker.SelectedItem = course.Status;
            InstructorNameEntry.Text = course.InstructorName;
            InstructorPhoneEntry.Text = course.InstructorPhone;
            InstructorEmailEntry.Text = course.InstructorEmail;
            NotesEditor.Text = course.Notes;
            EnableNotificationsSwitch.IsToggled = course.EnableNotifications;
        }

        private async void Save_Clicked(object sender, EventArgs e)
        {
            // Validation for empty fields
            if (string.IsNullOrWhiteSpace(TitleEntry.Text))
            {
                await DisplayAlert("Error", "Course Title is required.", "OK");
                return;
            }

            if (StartDatePicker.Date == null)
            {
                await DisplayAlert("Error", "Start Date is required.", "OK");
                return;
            }

            if (EndDatePicker.Date == null)
            {
                await DisplayAlert("Error", "End Date is required.", "OK");
                return;
            }

            if (string.IsNullOrWhiteSpace(InstructorNameEntry.Text))
            {
                await DisplayAlert("Error", "Instructor Name is required.", "OK");
                return;
            }

            if (!ValidatePhoneNumber(InstructorPhoneEntry.Text))
            {
                await DisplayAlert("Error", "Invalid phone number format. Use xxx-xxx-xxxx.", "OK");
                return;
            }

            if (!ValidateEmail(InstructorEmailEntry.Text))
            {
                await DisplayAlert("Error", "Invalid email address format.", "OK");
                return;
            }

            if (StatusPicker.SelectedItem == null)
            {
                await DisplayAlert("Error", "Course Status is required.", "OK");
                return;
            }

            // Ensure End Date is not before Start Date
            if (EndDatePicker.Date < StartDatePicker.Date)
            {
                await DisplayAlert("Error", "End Date cannot be before Start Date.", "OK");
                return;
            }

            if (_courseToEdit == null)
            {
                var newCourse = new Course
                {
                    TermId = _termId,
                    Title = TitleEntry.Text,
                    StartDate = StartDatePicker.Date,
                    EndDate = EndDatePicker.Date,
                    Status = (string)StatusPicker.SelectedItem,
                    InstructorName = InstructorNameEntry.Text,
                    InstructorPhone = InstructorPhoneEntry.Text,
                    InstructorEmail = InstructorEmailEntry.Text,
                    Notes = NotesEditor.Text,
                    EnableNotifications = EnableNotificationsSwitch.IsToggled
                };

                Globals.AddCourseToCourseCollection(newCourse);
            }
            else
            {
                _courseToEdit.Title = TitleEntry.Text;
                _courseToEdit.StartDate = StartDatePicker.Date;
                _courseToEdit.EndDate = EndDatePicker.Date;
                _courseToEdit.Status = (string)StatusPicker.SelectedItem;
                _courseToEdit.InstructorName = InstructorNameEntry.Text;
                _courseToEdit.InstructorPhone = InstructorPhoneEntry.Text;
                _courseToEdit.InstructorEmail = InstructorEmailEntry.Text;
                _courseToEdit.Notes = NotesEditor.Text;
                _courseToEdit.EnableNotifications = EnableNotificationsSwitch.IsToggled;

                Globals.UpdateCourseInCourseCollection(_courseToEdit, _courseToEdit);
            }

            await Navigation.PopModalAsync();
        }

        private bool ValidatePhoneNumber(string phoneNumber)
        {
            return Regex.IsMatch(phoneNumber, @"^\d{3}-\d{3}-\d{4}$");
        }

        private bool ValidateEmail(string email)
        {
            return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        private async void Cancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopModalAsync();
        }
    }
}
