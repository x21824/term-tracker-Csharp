﻿using System;
using System.Globalization;
using TermTracker.Models;
using Microsoft.Maui.Controls;

namespace TermTracker.Views
{
    public partial class TermPage : ContentPage
    {
        public Term SelectedTerm { get; set; }

        public TermPage(Term term)
        {
            Globals.InitializeCoursesCollection(term.Id);
            InitializeComponent();
            SelectedTerm = term;
            SetData(term);
        }

        public void SetData(Term term)
        {
            navTitle.Text = term.Title;
            TermDateRange.Text = $"{term.StartDate.ToString("MM-dd-yyyy", DateTimeFormatInfo.InvariantInfo)} - {term.EndDate.ToString("MM-dd-yyyy", DateTimeFormatInfo.InvariantInfo)}";
        }

        private async void AddCourse_Clicked(object sender, EventArgs e)
        {
            try
            {
                if (Globals.Courses.Count >= 6)
                {
                    await DisplayAlert("Error", "You cannot add more than 6 courses to a term.", "OK");
                    return;
                }

                await Navigation.PushModalAsync(new CourseConstructPage(SelectedTerm.Id));
            }
            catch (Exception error)
            {
                await DisplayAlert("Alert", $"{error.Message}", "OK");
            }
        }

        private async void EditTerm_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new TermConstructPage(SelectedTerm));
        }

        private async void DeleteTerm_Clicked(object sender, EventArgs e)
        {
            bool confirm = await DisplayAlert("Confirm", "Are you sure you want to delete this term?", "Yes", "No");
            if (confirm)
            {
                Globals.DeleteTermFromTermCollection(SelectedTerm);
                await Navigation.PopAsync();
            }
        }

        private async void Course_Clicked(object sender, EventArgs e)
        {
            var layout = (BindableObject)sender;
            var course = (Course)layout.BindingContext;
            await Navigation.PushAsync(new CoursePage(course));
        }
    }
}
