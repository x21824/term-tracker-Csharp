﻿using Microsoft.Maui.Controls;
using TermTracker.Models;

namespace TermTracker.Views
{
    public partial class TermConstructPage : ContentPage
    {
        private readonly Term _termToEdit;

        public TermConstructPage()
        {
            InitializeComponent();
            _termToEdit = null;
        }

        public TermConstructPage(Term term)
        {
            InitializeComponent();
            _termToEdit = term;
            SetData(term);

            // Make the delete button visible if we are editing an existing term
            DeleteButton.IsVisible = true;
        }

        private void SetData(Term term)
        {
            TitleEntry.Text = term.Title;
            StartDatePicker.Date = term.StartDate;
            EndDatePicker.Date = term.EndDate;
        }

        private async void Save_Clicked(object sender, EventArgs e)
        {
            // Validation for empty fields
            if (string.IsNullOrWhiteSpace(TitleEntry.Text))
            {
                await DisplayAlert("Error", "Term Title is required.", "OK");
                return;
            }

            if (StartDatePicker.Date == null)
            {
                await DisplayAlert("Error", "Start Date is required.", "OK");
                return;
            }

            if (EndDatePicker.Date == null)
            {
                await DisplayAlert("Error", "End Date is required.", "OK");
                return;
            }

            // Ensure End Date is not before Start Date
            if (EndDatePicker.Date < StartDatePicker.Date)
            {
                await DisplayAlert("Error", "End Date cannot be before Start Date.", "OK");
                return;
            }

            if (_termToEdit == null)
            {
                var newTerm = new Term
                {
                    Title = TitleEntry.Text,
                    StartDate = StartDatePicker.Date,
                    EndDate = EndDatePicker.Date
                };

                Globals.AddTermToTermCollection(newTerm);
            }
            else
            {
                _termToEdit.Title = TitleEntry.Text;
                _termToEdit.StartDate = StartDatePicker.Date;
                _termToEdit.EndDate = EndDatePicker.Date;

                Globals.UpdateTermInTermCollection(_termToEdit, _termToEdit);
            }

            await Navigation.PopModalAsync();
        }

        private async void Cancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopModalAsync();
        }

        private async void Delete_Clicked(object sender, EventArgs e)
        {
            if (_termToEdit != null)
            {
                bool confirm = await DisplayAlert("Confirm", "Are you sure you want to delete this term?", "Yes", "No");
                if (confirm)
                {
                    Globals.DeleteTermFromTermCollection(_termToEdit);
                    await Navigation.PopModalAsync();
                }
            }
            else
            {
                await DisplayAlert("Error", "You cannot delete an unsaved term.", "OK");
            }
        }
    }
}
