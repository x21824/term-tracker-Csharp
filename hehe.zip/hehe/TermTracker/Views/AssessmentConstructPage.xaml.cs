﻿using System;
using System.Linq;
using TermTracker.Models;
using Microsoft.Maui.Controls;

namespace TermTracker.Views
{
    public partial class AssessmentConstructPage : ContentPage
    {
        private readonly int _courseId;
        private readonly Assessment _assessmentToEdit;

        public AssessmentConstructPage(int courseId)
        {
            InitializeComponent();
            _courseId = courseId;
            _assessmentToEdit = null;
        }

        public AssessmentConstructPage(Assessment assessment)
        {
            InitializeComponent();
            _assessmentToEdit = assessment;
            _courseId = assessment.CourseId;  // Ensures that _courseId is set correctly during editing
            SetData(assessment);
        }

        private void SetData(Assessment assessment)
        {
            TitleEntry.Text = assessment.Title;
            StartDatePicker.Date = assessment.StartDate;
            EndDatePicker.Date = assessment.EndDate;
            TypePicker.SelectedItem = assessment.Type;
            EnableNotificationsSwitch.IsToggled = assessment.EnableNotifications;
        }

        private async void Save_Clicked(object sender, EventArgs e)
        {
            // Validation for empty fields
            if (string.IsNullOrWhiteSpace(TitleEntry.Text))
            {
                await DisplayAlert("Error", "Assessment Title is required.", "OK");
                return;
            }

            if (TypePicker.SelectedItem == null)
            {
                await DisplayAlert("Error", "Assessment Type is required.", "OK");
                return;
            }

            // Ensure End Date is not before Start Date
            if (EndDatePicker.Date < StartDatePicker.Date)
            {
                await DisplayAlert("Error", "End Date cannot be before Start Date.", "OK");
                return;
            }

            var selectedType = (string)TypePicker.SelectedItem;

            // Final check for duplicate assessment types within the same course
            var existingAssessments = Globals.GetAssessmentsForCourse(_courseId);

            if (existingAssessments.Any(a => a.Type == selectedType && a.Id != _assessmentToEdit?.Id))
            {
                await DisplayAlert("Error", $"A {selectedType} assessment already exists for this course.", "OK");
                return;
            }

            if (_assessmentToEdit == null)
            {
                // Creating a new assessment
                var newAssessment = new Assessment
                {
                    CourseId = _courseId,
                    Title = TitleEntry.Text,
                    StartDate = StartDatePicker.Date,
                    EndDate = EndDatePicker.Date,
                    Type = selectedType,
                    EnableNotifications = EnableNotificationsSwitch.IsToggled
                };

                Globals.AddAssessmentToAssessmentCollection(newAssessment);
            }
            else
            {
                // Editing an existing assessment
                _assessmentToEdit.Title = TitleEntry.Text;
                _assessmentToEdit.StartDate = StartDatePicker.Date;
                _assessmentToEdit.EndDate = EndDatePicker.Date;
                _assessmentToEdit.Type = selectedType;
                _assessmentToEdit.EnableNotifications = EnableNotificationsSwitch.IsToggled;

                Globals.UpdateAssessmentInAssessmentCollection(_assessmentToEdit, _assessmentToEdit);
            }

            await Navigation.PopModalAsync();
        }

        private async void Cancel_Clicked(object sender, EventArgs e)
        {
            await Navigation.PopModalAsync();
        }

        private async void Delete_Clicked(object sender, EventArgs e)
        {
            if (_assessmentToEdit != null)
            {
                bool confirm = await DisplayAlert("Confirm", "Are you sure you want to delete this assessment?", "Yes", "No");
                if (confirm)
                {
                    Globals.DeleteAssessmentFromAssessmentCollection(_assessmentToEdit);
                    await Navigation.PopModalAsync();
                }
            }
            else
            {
                await DisplayAlert("Error", "You cannot delete an unsaved assessment.", "OK");
            }
        }
    }
}
