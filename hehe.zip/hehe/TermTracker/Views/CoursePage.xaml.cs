﻿using System;
using TermTracker.Models;
using Microsoft.Maui.Controls;

namespace TermTracker.Views
{
    public partial class CoursePage : ContentPage
    {
        public Course SelectedCourse { get; set; }

        public CoursePage(Course course)
        {
            InitializeComponent();
            SelectedCourse = course;
            SetData(course);
        }

        public void SetData(Course course)
        {
            navTitle.Text = course.Title;
            CourseDateRange.Text = $"{course.StartDate:MM-dd-yyyy} - {course.EndDate:MM-dd-yyyy}";
            CourseStatus.Text = course.Status;
            InstructorName.Text = course.InstructorName;
            InstructorPhone.Text = course.InstructorPhone;
            InstructorEmail.Text = course.InstructorEmail;
            CourseNotes.Text = course.Notes;
        }

        private async void ViewAssessments_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new AssessmentsPage(SelectedCourse.Id));
        }


        private async void EditCourse_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new CourseConstructPage(SelectedCourse.Id));
        }

        private async void DeleteCourse_Clicked(object sender, EventArgs e)
        {
            try
            {
                bool confirm = await DisplayAlert("Confirm", "Are you sure you want to delete this course?", "Yes", "No");
                if (confirm)
                {
                    Globals.DeleteCourseFromCourseCollection(SelectedCourse);
                    await Navigation.PopAsync();
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            }
        }

    }
}
