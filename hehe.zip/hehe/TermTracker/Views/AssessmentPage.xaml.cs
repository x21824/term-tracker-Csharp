﻿using Microsoft.Maui.Controls;
using TermTracker.Models;

namespace TermTracker.Views
{
    public partial class AssessmentPage : ContentPage
    {
        public Assessment SelectedAssessment { get; set; }

        public AssessmentPage(Assessment assessment)
        {
            InitializeComponent();
            SelectedAssessment = assessment;
            SetData(assessment);
        }

        public void SetData(Assessment assessment)
        {
            AssessmentTitle.Text = assessment.Title;
            AssessmentDateRange.Text = $"{assessment.StartDate:MM-dd-yyyy} - {assessment.EndDate:MM-dd-yyyy}";
            AssessmentType.Text = assessment.Type;
        }

        private async void EditAssessment_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new AssessmentConstructPage(SelectedAssessment));
        }

        private async void DeleteAssessment_Clicked(object sender, EventArgs e)
        {
            bool confirm = await DisplayAlert("Confirm", "Are you sure you want to delete this assessment?", "Yes", "No");
            if (confirm)
            {
                Globals.DeleteAssessmentFromAssessmentCollection(SelectedAssessment);
                await Navigation.PopAsync();
            }
        }
    }
}
