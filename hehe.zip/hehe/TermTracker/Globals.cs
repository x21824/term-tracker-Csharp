﻿using Plugin.LocalNotification;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using TermTracker.Database;
using TermTracker.Models;
namespace TermTracker
    {
        public static class Globals
        {
            public static ObservableCollection<Term> Terms = new ObservableCollection<Term>();
            public static ObservableCollection<Course> Courses = new ObservableCollection<Course>();
            public static ObservableCollection<Assessment> Assessments = new ObservableCollection<Assessment>();

            public static void StartupNotifications()
            {
                var today = DateTime.Today;
                var database = new SqliteDataService();
                database.Initialize();

                var courses = database.GetAllCourses();
                var assessments = database.GetAllAssessments();

                courses.ForEach(course =>
                {
                    if (course.EnableNotifications && course.StartDate.Date == today)
                    {
                        var notification = new NotificationRequest
                        {
                            NotificationId = course.Id,
                            Title = "Course Start",
                            Description = $"{course.Title} is starting today",
                            Schedule = new NotificationRequestSchedule
                            {
                                NotifyTime = DateTime.Now.AddSeconds(5) 
                            }
                        };
                        LocalNotificationCenter.Current.Show(notification);
                    }
                    if (course.EnableNotifications && course.EndDate.Date == today)
                    {
                        var notification = new NotificationRequest
                        {
                            NotificationId = course.Id,
                            Title = "Course End",
                            Description = $"{course.Title} is ending today",
                            Schedule = new NotificationRequestSchedule
                            {
                                NotifyTime = DateTime.Now.AddSeconds(5) 
                            }
                        };
                        LocalNotificationCenter.Current.Show(notification);
                    }
                });

                assessments.ForEach(assessment =>
                {
                    if (assessment.EnableNotifications && assessment.StartDate.Date == today)
                    {
                        var notification = new NotificationRequest
                        {
                            NotificationId = assessment.Id,
                            Title = "Assessment Start",
                            Description = $"{assessment.Title} starts today",
                            Schedule = new NotificationRequestSchedule
                            {
                                NotifyTime = DateTime.Now.AddSeconds(5)
                            }
                        };
                        LocalNotificationCenter.Current.Show(notification);
                    }
                    if (assessment.EnableNotifications && assessment.EndDate.Date == today)
                    {
                        var notification = new NotificationRequest
                        {
                            NotificationId = assessment.Id,
                            Title = "Assessment End",
                            Description = $"{assessment.Title} ends today",
                            Schedule = new NotificationRequestSchedule
                            {
                                NotifyTime = DateTime.Now.AddSeconds(5)
                            }
                        };
                        LocalNotificationCenter.Current.Show(notification);
                    }
                });

                database.Close();
            }

            public static void InitializeTermsCollection()
            {
                var database = new SqliteDataService();
                database.Initialize();
                var terms = database.GetAllTerms();
                terms.ForEach(term => Terms.Add(term));
                database.Close();
            }

            public static void AddTermToTermCollection(Term term)
            {
                var database = new SqliteDataService();
                database.Initialize();
                database.AddTerm(term);
                Terms.Add(term);
                database.Close();
            }

            public static void UpdateTermInTermCollection(Term oldTerm, Term newTerm)
            {
                var termList = Terms.ToList();
                Terms.Clear();

                var database = new SqliteDataService();
                database.Initialize();
                database.UpdateTerm(newTerm);

                int indexFound = termList.IndexOf(oldTerm);
                termList.RemoveAt(indexFound);
                termList.Insert(indexFound, newTerm);
                termList.ForEach(term => Terms.Add(term));

                database.Close();
            }

            public static void DeleteTermFromTermCollection(Term term)
            {
                var database = new SqliteDataService();
                database.Initialize();
                database.DeleteTerm(term);
                Terms.Remove(term);
                database.Close();
            }

            public static void InitializeCoursesCollection(int termId)
            {
                Courses.Clear();
                var database = new SqliteDataService();
                database.Initialize();
                var courses = database.GetCoursesByTermId(termId);
                courses.ForEach(course => Courses.Add(course));
                database.Close();
            }

            public static void AddCourseToCourseCollection(Course course)
            {
                var database = new SqliteDataService();
                database.Initialize();
                database.AddCourse(course);
                Courses.Add(course);
                database.Close();
            }

            public static void UpdateCourseInCourseCollection(Course oldCourse, Course newCourse)
            {
                var courseList = Courses.ToList();
                Courses.Clear();

                var database = new SqliteDataService();
                database.Initialize();
                database.UpdateCourse(newCourse);

                int indexFound = courseList.IndexOf(oldCourse);
                courseList.RemoveAt(indexFound);
                courseList.Insert(indexFound, newCourse);
                courseList.ForEach(course => Courses.Add(course));

                database.Close();
            }

            public static void DeleteCourseFromCourseCollection(Course course)
            {
                var database = new SqliteDataService();
                database.Initialize();
                database.DeleteCourse(course);
                Courses.Remove(course);
                database.Close();
            }

            public static void InitializeAssessmentCollection(int courseId)
            {
                Assessments.Clear();
                var database = new SqliteDataService();
                database.Initialize();
                var assessments = database.GetAssessmentsByCourseId(courseId);
                assessments.ForEach(assessment => Assessments.Add(assessment));
                database.Close();
            }

            public static void AddAssessmentToAssessmentCollection(Assessment assessment)
            {
                var database = new SqliteDataService();
                database.Initialize();
                database.AddAssessment(assessment);
                Assessments.Add(assessment);
                database.Close();
            }

            public static void UpdateAssessmentInAssessmentCollection(Assessment oldAssessment, Assessment newAssessment)
            {
                var assessmentList = Assessments.ToList();
                Assessments.Clear();

                var database = new SqliteDataService();
                database.Initialize();
                database.UpdateAssessment(newAssessment);

                int indexFound = assessmentList.IndexOf(oldAssessment);
                assessmentList.RemoveAt(indexFound);
                assessmentList.Insert(indexFound, newAssessment);
                assessmentList.ForEach(assessment => Assessments.Add(assessment));

                database.Close();
            }

            public static void DeleteAssessmentFromAssessmentCollection(Assessment assessment)
            {
                var database = new SqliteDataService();
                database.Initialize();
                database.DeleteAssessment(assessment);
                Assessments.Remove(assessment);
                database.Close();
            }

            public static List<Assessment> GetAssessmentsForCourse(int courseId)
            {
                return Assessments.Where(a => a.CourseId == courseId).ToList();
            }
    }
    }

